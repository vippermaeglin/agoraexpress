xBaseView - Universal Database Viewer-Editor
Version 7.2 Pro (Build 0661)

xBaseView is a multifunctional database tool which designed for the novice database administrators or the advanced users of databases. It looks like Microsoft Windows Explorer and it allows you to work with databases just like in Explorer: the database files are displayed in the folder-tree and you can open it by the mouse. With xBaseView, you can perform all typical operations with databases, such as searching, filtering and printing of records. It can open any database via the ADO, ODBC and BDE universal industrial technologies, and can directly open 15 types of databases. xBaseView provides direct export of the data to 16 formats (direct import - from 14 formats), and it can export (and import) them to any format of databases via the universal technologies. The database experts can create up to 10 various types of files; can perform SQL-queries and other operations.

Review and editing of files with extensions
- .DBF	FoxPro,
- .DBF	dBase,
- .DBF	Clipper,
- .DBC	Visual FoxPro,
- .DB  	Paradox,
- .MDB	Access,
- .MYD	MySQL,
- .GDB	Interbase,
- .FDB	Firebird,
- .MDF	MS SQL Server,
- .XLS 	Excel,
- .CSV	CSV Text,
- .TAB	TAB Text,
- .HTM	HTML Text,
- .HTML	HTML Text,
- .XML	Microsoft ADO XML,
- .XML	Borland Data Packet XML,
- .CDS	Borland Client Data Set,
- .UDL	ADO Universal Data Link,
- .DSN	ODBC Data Source Name,
- .BDE	Borland DB Engine Aliases.

Key features
- Access to 3 universal file extensions: UDL, DSN, BDE.
- Direct access to 15 file extensions: DBF, DBC, DB, MDB, MYD, GDB, FDB, MDF, XLS, CSV, TAB, HTM, HTML, XML, CDS.
- Export to 2 universal database formats: UDL, DSN.
- Direct export to 16 database formats: TXT, XLS, CSV, TAB, HTM, Simple XML, CDS XML, ADO XML, DBF, DB, MYD, MDB, DBC, GDB, FDB, MDF.
- Import from 2 universal database formats: UDL, DSN.
- Direct import from 14 database formats: CSV, TAB, HTM, CDS XML, ADO XML, DBF, DB, MYD, CDS, MDB, DBC, GDB, FDB, MDF.
- Creation of 10 files types: DBF, DB, MYD, MDB, DBC, GDB, FDB, MDF, UDL, DSN.
- Search records by 3 ways: sequential, index and step-by-step.
- Filtering records by 2 ways: SQL- like and index.
- Execution SQL queries and other SQL-operators.
- Generation Create Table SQL-operators for different databases.
- Creation and modification of structures for DBF / DB files.
- Creation and modification of indexes for DBF / DB files.
- Reindex, pack or zap of DBF / DB files.
- Setting code of characters for DBF / DB files.
- Characters translation in DBF files.
- Using 6 technologies of access to databases: Microsoft ADO, Microsoft ODBC, Borland dbExpress, Borland Database Engine, MySQLDAC Engine, xBase DBF Engine.
- The xBase DBF Engine automatically opens and correctly uses all types of index (CDX, IDX, MDX, NDX, NTX) and memo (FPT, DBT) files for DBF; recognizes DBF's code pages and national characters; supports different collates, including General Collate, for VFP and FoxPro; supports auto incremental fields for VFP 8 and new DBF-formats for VFP 9.

Many thanks to:
- Andrey Pyasetskiy for Totalcmd.net
- Christian Ghisler for Total Commander
- MicroOLAP LLC for MySQL DAC Controls
- Nullsoft Incorporated for NSIS Installer
- Troy Wolbrink for Tnt Unicode Controls

Many thanks for translation to foreign languages:
- Dutch:      Erwin Veermans
- French:     Franck Gartemann, Claude Charries
- German:     Dieter Rehfeld, Juergen Luethje
- Greek:      Dimitrios Valsamis
- Italian:    Diamanti, Pierluigi Montinaro
- Polish:     Bogdan Wozniak
- Spanish:    Luis Mejia, Martin Rissoto
- Ukrainian:  Serhiy Dubyk

Many thanks to beta-testers:
  Alexey<sdhw@postman.ru>,
  StayAtHome<stayathome@nm.ru>,
  Poiutur<dimon@ldz.lv>,
  Superman<Mike_G@ufamts.ru>,
  Li<Lgogi@mail.ru>,
  Serge<egres@fromru.com>,
  AkulaBig<akulabig@trktvs.ru>.

Copyright � 2004-2006 Mutex LLC.
www.xbaseview.com
